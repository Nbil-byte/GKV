google.charts.load('current', {packages: ['corechart', 'bar']});
google.charts.setOnLoadCallback(drawChart);

function drawChart() {
    d3.csv('produksi_mangga_per_kabupaten_2021_2022.csv').then(function(data) {

        let chartData = [['Kabupaten/Kota', 'Produksi 2021', 'Produksi 2022']];
        data.forEach(row => {
            chartData.push([row.nama_kabupaten_kota, parseInt(row.produksi_2021), parseInt(row.produksi_2022)]);
        });

      
        var dataTable = google.visualization.arrayToDataTable(chartData);

        var options = {
            title: 'Perbandingan Produksi Mangga Setiap Kabupaten/Kota (2021 vs 2022)',
            chartArea: {width: '50%'},
            colors: ['#2D4059', '#F07B3F'],
            hAxis: {
                title: 'Produksi (Kuintal)',
                minValue: 0,
                textStyle: {
                    bold: true,
                    fontSize: 12,
                    color: '#4d4d4d'
                },
                titleTextStyle: {
                    bold: true,
                    fontSize: 18,
                    color: '#4d4d4d'
                }
            },
            vAxis: {
                title: 'Kabupaten/Kota',
                textStyle: {
                    fontSize: 14,
                    bold: true,
                    color: '#848484'
                },
                titleTextStyle: {
                    fontSize: 14,
                    bold: true,
                    color: '#848484'
                }
            }
        };

        var chart = new google.visualization.BarChart(document.getElementById('chart_div'));
        chart.draw(dataTable, options);
    }).catch(function(error) {
        console.error('Error loading the CSV file:', error);
    });
}
